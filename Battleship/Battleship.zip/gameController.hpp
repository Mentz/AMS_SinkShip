#ifndef GAME_CONTROLLER_HPP
#define GAME_CONTROLLER_HPP

#include <utility>
#include <SFML/Graphics.hpp>
#include "grid.hpp"
#include "embarcacao.hpp"

class GameController {

private:
    Grid *gA, *gB;
    int player_da_vez;
    int tamJanela;
    vector<Embarcacao> naviosA, naviosB;
public:

    GameController(int tamJanela){
        this -> tamJanela = tamJanela;
        gA = new Grid(tamJanela);
        gB = new Grid(tamJanela);
        naviosA.clear();
        naviosB.clear();
        this -> player_da_vez = 1;
        int id = 1;
        //Criando os Submarinos
        for(int i = 0; i < 4; i++){
            naviosA.push_back(Embarcacao(id, SUBMARINO));
            naviosB.push_back(Embarcacao(id++, SUBMARINO));
        }

        //Criando os ContraTorpedeiros
        for(int i = 0; i < 3; i++){
            naviosA.push_back(Embarcacao(id, CONTRATORPEDEIROS));
            naviosB.push_back(Embarcacao(id++, CONTRATORPEDEIROS));
        }

        //Criando os Submarinos
        for(int i = 0; i < 2; i++){
            naviosA.push_back(Embarcacao(id, NAVIO_TANQUE));
            naviosB.push_back(Embarcacao(id++, NAVIO_TANQUE));
        }

        //Criando os Submarinos
        naviosA.push_back(Embarcacao(id, PORTA_AVIAO));
        naviosB.push_back(Embarcacao(id, PORTA_AVIAO));
    }

    pair<int,int> getMouseClickPos(sf::RenderWindow &window){
        sf::Vector2i p = sf::Mouse::getPosition(window);
        pair<int,int> pos;
        pos.first = p.x;
        pos.second = p.y;
        return pos;
    }

    bool valid(pair<int, int> pos){
        return (pos.first >= 0 and pos.second >= 0 and pos.first < TAM_CAMPO and pos.second < TAM_CAMPO);
    }

    void setPlayer(int player_da_vez){
        this -> player_da_vez = player_da_vez;
    }

    int getPlayer(){
        return player_da_vez;
    }

    Celula getCelula(pair<int,int> pos){
        if(valid(pos)){
            if(player_da_vez == 1){
                return gA -> getCelula(pos);
            } else {
                return gB -> getCelula(pos);
            }
        }
        return Celula();
    }

    void setMorto(pair<int, int> pos){
        if(valid(pos)){
            if(player_da_vez == 1){
                gA -> setMorto(pos);
                int id = gA -> getCelula(pos).getIdBarco();
                if(id != -1){
                    int parte = gA -> getCelula(pos).getParte();
                    naviosA[id - 1].mataCorpo(parte - 1);
                }
            } else {
                gB -> setMorto(pos);
                int id = gB -> getCelula(pos).getIdBarco();
                if(id != -1){
                    int parte = gB -> getCelula(pos).getParte();
                    naviosB[id - 1].mataCorpo(parte - 1);
                }
            }
            
        }
    }

    void render(sf::RenderWindow &window, vector<sf::Texture> &texturas, bool fimJogo = false){
        if(player_da_vez == 1){
            gA -> render(window, naviosA, texturas, fimJogo);
        } else {
            gB -> render(window, naviosB, texturas, fimJogo);
        }
    }

    void gerarNovoJogo(){
        gA = new Grid(tamJanela);
        gB = new Grid(tamJanela);
    }

    bool fimJogo(){
        if(player_da_vez == 1){
            for(int i = 0; i < naviosA.size(); i++){
                if(!naviosA[i].estaMorto()){
                    return false;
                }
            }
            return true;
        } else {
            for(int i = 0; i < naviosB.size(); i++){
                if(!naviosB[i].estaMorto()){
                    return false;
                }
            }
            return true;
        }
    }

    void mostrarFimJogo(){
        


    }

};

#endif
