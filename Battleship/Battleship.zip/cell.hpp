#ifndef CELL_HPP
#define CELL_HPP

#include <utility>
#include <SFML/Graphics.hpp>

using namespace std;

class Celula {
private:
    int id_barco;
    bool morto;
    int parte;
    string filename;

public:
    Celula(int id_barco = -1, int parte = -1, string filename = "Imagens/agua.png"){
        morto = false;
        this -> id_barco = id_barco;
        this -> parte = parte;
        this -> filename = filename;
    } 

    void setMorto(){
        this -> morto = true;
    }

    void setIdBarco(int id){
        id_barco = id;
    }
    void setParte(int parte){
        this -> parte = parte;
    }

    bool getMorto(){
        return morto;
    }

    int getIdBarco(){
        return id_barco;
    }

    string getFilename(){
        return filename;
    }

    void setFilename(string filename){
        this -> filename = filename;
    }

    /*void setColor(int id){

        switch(id){
            case 1:
                cor = sf::Color(125, 0, 64);
                break;
            case 2:
                cor = sf::Color(210, 150, 20);
                break;
            case 3:
                cor = sf::Color(30, 240, 120);
                break;
            case 4:
                cor = sf::Color(210, 66, 100);
                break;
            case 5:
                cor = sf::Color(200, 200, 0);
                break;
            case 6:
                cor = sf::Color(125, 125, 222);
                break;
            case 7:
                cor = sf::Color(54, 38, 160);
                break;
            case 8:
                cor = sf::Color(55, 163, 178);
                break;  
            case 9:
                cor = sf::Color(96, 180, 96);
                break;
            case 10:
                cor = sf::Color(48, 48, 150);
                break;
        }

    }*/

    int getParte(){
        return parte;
    }
};

#endif