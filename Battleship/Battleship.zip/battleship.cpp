#include <SFML/Graphics.hpp>
#include <bits/stdc++.h>

#include "gameController.hpp"

using namespace std;

#define TAM_JANELA 480

void fullTextures(vector<sf::Texture> &vet){
    for(int i = 0; i < TAM_CAMPO * TAM_CAMPO; i++){
        sf::Texture temp;
        vet.push_back(temp);
    }
}

int main(int argc, const char *argv[]){

    sf::RenderWindow window(sf::VideoMode(TAM_JANELA, TAM_JANELA), "SinkShip - Jogador da vez: 1");
    vector<sf::Texture> texturas1, texturas2;
    srand(time(NULL));
    fullTextures(texturas1);
    fullTextures(texturas2);
    GameController *gc = new GameController(TAM_JANELA);
    bool noGame = false;
    while(window.isOpen()){
        if(noGame){
            window.setTitle("SinkShip - Fim de jogo");
            sf::Font font;
            font.loadFromFile("Fontes/Aller_Bd.ttf");
            sf::Text text;
            text.setFont(font);
            text.setCharacterSize(35);
            text.setColor(sf::Color(220, 20, 60));
            text.setString("Jogador vencedor: " + to_string(gc -> getPlayer()));
            text.setPosition(sf::Vector2f(TAM_JANELA / 2 - 170, TAM_JANELA / 2 - 55));

            sf::Event evnt;

            while(window.pollEvent(evnt)){
                if(evnt.type == sf::Event::Closed){
                    window.close();
                }
            }

            window.clear(sf::Color::White);

            gc -> render(window, (gc -> getPlayer() == 1 ? texturas1 : texturas2), true);

            window.draw(text);
            window.display();
        } else {
            window.setTitle("SinkShip - Jogador da vez: " + to_string(gc -> getPlayer()));
            sf::Event evnt;
            bool f = false;
            bool sshot = false;
            while(window.pollEvent(evnt)){
                if(evnt.type == sf::Event::Closed){
                    window.close();
                }
                if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
                    pair<int, int> posMouse = gc -> getMouseClickPos(window);
                    posMouse.first = floor(posMouse.first / (double)((TAM_JANELA / TAM_CAMPO)));
                    posMouse.second = floor(posMouse.second / (double)((TAM_JANELA / TAM_CAMPO)));
                    if(!gc -> getCelula(posMouse).getMorto()){
                        gc -> setMorto(posMouse);
                        if(gc -> fimJogo()){
                            noGame = true;
                            break;
                        }
                        sshot = (gc -> getCelula(posMouse).getIdBarco() != -1);
                        f = true;
                    }
                }
            }
            window.clear(sf::Color::White);
            gc -> render(window, (gc -> getPlayer() == 1 ? texturas1 : texturas2));
            window.display();
            if(f){
                sf::Time t = sf::milliseconds(500.f);
                sf::sleep(t);
                if(!sshot){
                    gc -> setPlayer((gc -> getPlayer() == 1 ? 2 : 1));
                }
            }
        }
    }

    return 0;
}
